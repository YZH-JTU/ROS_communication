
float heading_angle = 0;
double latitude = 0;
double longitude = 0;

unsigned int stress_data = 0;