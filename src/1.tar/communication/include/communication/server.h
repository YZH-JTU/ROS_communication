#ifndef _SERVER_H
#define _SERVER_H

#ifdef __cplusplus
extern "C" {
#endif
extern int startup_socket_PLC(void);
extern int startup_socket_MONITOR(void);
#ifdef __cplusplus
}
#endif

#endif
